package com.azamajohan.predictionbot

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.resultsInput)
        result = findViewById(R.id.predictionResult)
        val analyze = findViewById<Button>(R.id.analyzeButton)

        analyze.setOnClickListener {
            analyzeHistory()
        }
    }

    private fun analyzeHistory() {
        val values = input.text.toString()
            .split(",", ";", " ", "\n".toRegex())
            .mapNotNull { it.trim().toDoubleOrNull() }
            .takeLast(30)

        if (values.size < 3) {
            result.text = "Entre au moins 3 résultats numériques pour lancer l'analyse."
            return
        }

        val avg = values.average()
        val recent = values.takeLast(minOf(5, values.size)).average()
        val min = values.minOrNull() ?: 0.0
        val max = values.maxOrNull() ?: 0.0

        val trend = when {
            recent > avg * 1.08 -> "hausse récente"
            recent < avg * 0.92 -> "baisse récente"
            else -> "tendance stable"
        }

        val confidence = (50 + ((recent - avg).let { kotlin.math.abs(it) } /
                (kotlin.math.abs(avg) + 1.0) * 35)).roundToInt().coerceIn(50, 85)

        result.text = buildString {
            append("ANALYSE\n\n")
            append("Résultats analysés : ${values.size}\n")
            append("Moyenne : ${"%.2f".format(avg)}\n")
            append("Minimum : ${"%.2f".format(min)}\n")
            append("Maximum : ${"%.2f".format(max)}\n")
            append("Tendance : $trend\n")
            append("Indice statistique : $confidence%\n\n")
            append("⚠️ Ceci est une analyse simple de données historiques. ")
            append("Elle ne garantit pas le résultat futur.")
        }
    }
}
