# Prediction Bot Android

Application Android de démonstration pour analyser des résultats numériques historiques.

## Compilation
Le workflow GitHub Actions situé dans `.github/workflows/android.yml` construit automatiquement un APK debug.

## Utilisation
1. Ouvrir l'application.
2. Entrer au moins 3 résultats séparés par des virgules.
3. Appuyer sur ANALYSER.
4. Lire la tendance et les statistiques.

Cette version est une base technique : elle ne garantit pas les résultats futurs et n'utilise pas encore une source de données distante en temps réel.
